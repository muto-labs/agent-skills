(() => {
'use strict';
const D = JSON.parse(document.getElementById('plan-data').textContent);
const main = document.getElementById('main');
const pillars = [['God','Spiritual relationship','G'],['Fit','Fitness','F'],['Fam','Family & friends','F'],['Biz','Job & business','B'],['$','Personal finances','$'],['Up','Personal development','U']];
const routes = [['overview','Overview','◈'],['foundation','Foundation','◇'],['objectives','Target Objectives','◎'],['quarter','Quarterly focus','▦'],['reviews','Reflection & reviews','↗'],['history','Year over year','≋'],['guide','Start here','?']];
const e = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const years = [...(D.years || [])].sort((a,b) => b.year-a.year);
const availableYears = years.length ? years.map(y=>y.year) : [new Date().getFullYear()];
let selected = availableYears[0];
let quarter = years[0]?.current_quarter || 1;
let pillarFilter = '', statusFilter = '';
const year = () => years.find(y => y.year === selected);
const active = rows => (rows || []).filter(r => r.review_state !== 'superseded');
const rows = () => active(year()?.objectives);
const isAccepted = r => r?.review_state === 'accepted';
const fmt = v => typeof v === 'number' ? v.toLocaleString(undefined,{maximumFractionDigits:2}) : '—';
function badge(text, type='') { return `<span class="badge ${e(type)}">${e(text)}</span>`; }
function progress(r) {
 if(r.mode === 'maintenance' || ![r.start,r.target,r.current].every(v => typeof v === 'number' && Number.isFinite(v)) || r.target === r.start) return null;
 const value=(r.current-r.start)/(r.target-r.start)*100;
 return Object.is(value,-0)?0:value;
}
function bar(r) {
 const p=progress(r);
 if(p===null) return `<div class="meta">${r.mode==='maintenance'?'Maintenance rule · see details':'Progress not yet measurable'}</div>`;
 return `<div class="progress-line"><span style="width:${Math.min(100,Math.max(0,p))}%"></span></div><div class="progress-label"><span>${fmt(p)}% toward target</span><span>${e(fmt(r.current))} / ${e(fmt(r.target))} ${e(r.unit)}</span></div>`;
}
function quarterReview(){ return year()?.quarter_reviews?.[String(quarter)] || (quarter===1?year()?.q1_commitment_review:null); }
function dimensionAccepted(r,key){return (r[key]??r.review_state)==='accepted';}
function intro(title,subtitle,kicker='YOUR STRATEGIC PLAN') {
 const locked=location.hash==='#quarter' && quarterReview()?.state==='locked';
 return `<div class="intro"><div><span class="eyebrow">${e(kicker)}</span><h1>${e(title)}</h1><p class="subtext">${e(subtitle)}</p></div>${badge(locked?'Q'+quarter+' locked':year()?.status==='accepted'?'Plan accepted':'Plan in development',locked||year()?.status==='accepted'?'accepted':'')}</div>`;
}
function empty(text) { return `<div class="empty">${e(text)}</div>`; }
function foundation() { return year()?.foundation || (selected===years[0]?.year ? D.foundation : {}) || {}; }
function tenetsList(text) {
 const items=Array.isArray(text)?text:String(text||'').split(/\r?\n/);
 return `<ul class="list tenets-list">${items.map(t=>String(t).replace(/^\s*[-•]\s*/, '').trim()).filter(Boolean).map(t=>{const colon=t.indexOf(':');return `<li>${colon<0?e(t):`<strong>${e(t.slice(0,colon+1))}</strong>${e(t.slice(colon+1))}`}</li>`;}).join('')}</ul>`;
}
function foundationCard(key,title,description) {
 const record=foundation()[key];
 const body=isAccepted(record) ? key==='tenets'?tenetsList(record.text):(Array.isArray(record.text)?`<ul class="list">${record.text.map(t=>`<li>${e(t)}</li>`).join('')}</ul>`:`<p class="foundation-text">${e(record.text)}</p>`) : empty(description);
 return `<article class="card foundation-card foundation-${e(key)}"><div class="pillar-top"><h3>${e(title)}</h3>${badge(isAccepted(record)?'Accepted':record?'Draft':'Not set',isAccepted(record)?'accepted':'')}</div>${body}<div class="card-foot"><span>${isAccepted(record)?'Reviewed '+e(record.reviewed_at||'date not recorded'):'Review in your conversation'}</span>${record?`<button class="text-button" data-foundation="${e(key)}">View details</button>`:''}</div></article>`;
}
function objectiveCard(r) {
 const index=pillars.findIndex(([p])=>p===r.pillar);
 return `<article class="card objective pillar-${index}"><div class="objective-heading"><div class="chips">${badge(r.pillar)}${badge(r.status||'Backlog',(r.status||'').toLowerCase())}${!isAccepted(r)?badge('Draft'):''}${r.quarter?badge(fmt(r.weight??100)+'% weight'):''}</div><h3>${e(r.description)}</h3></div><div class="objective-measure">${!r.quarter?`<div class="target-number">${e(r.metric==='$'?'$'+fmt(r.target):fmt(r.target))}<span>Target · ${e(r.metric==='$'?String(r.unit||'').replace(/^USD\s*/, ''):r.unit)}</span></div>`:''}${r.quarter&&progress(r)===null?'':bar(r)}</div><div class="card-foot"><span>Due ${e(r.due_date||'not set')}</span><button class="text-button" data-to="${e(r.id)}">Explore TO →</button></div>${r.as_of?`<p class="as-of meta">As of ${e(r.as_of)}</p>`:''}</article>`;
}
function overview() {
 const y=year(), word=y?.word, a=rows().filter(r=>!r.quarter);
 const displayWord = isAccepted(word) ? word.text : word ? 'Your word is taking shape.' : 'Choose your next direction.';
 return intro(`Make ${selected} count.`, 'Connect what matters to the results you want. One direction, six life pillars, and a focused quarter.', `${selected} · YOUR STRATEGIC PLAN`) +
 `<section class="hero" aria-label="Annual focus"><div><span class="eyebrow">${e(selected||'THE YEAR AHEAD')} · WORD OF THE YEAR</span><div class="word">${e(displayWord)}</div><p class="subtext">${e(isAccepted(word)?word.meaning_review_state==='draft'?'Your personal definition is awaiting review.':word.meaning||'Define what this word calls you to do.':'An action word or short phrase to guide your decisions, Target Objectives, and habits.')}</p>${word?`<button class="text-button" data-word="true">Explore your word →</button>`:`<a class="text-button" href="#guide">See how to begin →</a>`}</div><div class="hero-next"><span class="eyebrow">YOUR PLAN IN MOTION</span><h3>${a.length} annual TOs · ${a.filter(r=>r.status==='Doing').length} active</h3><p>${quarterReview()?.state==='locked'?'Q'+quarter+' commitments locked':'Review your quarterly focus'}</p><a class="button small" href="#quarter">View Q${e(quarter)} focus →</a></div></section>` +
 `<div class="section-head"><h2>Your six life pillars</h2><a href="#objectives">View Target Objectives →</a></div><section class="grid overview-pillars" aria-label="Pillars">${pillars.map(([p,label,icon],index)=>{
 const r=a.find(r=>r.pillar===p);
 return `<article class="card pillar-card pillar-${index}"><div class="pillar-top"><span class="pillar-icon">${icon}</span><span class="pillar-name">${e(p)}</span>${badge(r?.status||'Not set',r?.status?.toLowerCase())}</div>${r?`<h3>${e(r.description)}</h3>${!isAccepted(r)?badge('Draft'):''}${bar(r)}`:`<h3>${e(label)}</h3>${empty('Your annual result will take shape here.')}`}<div class="card-foot"><span>${r?'Due '+e(r.due_date||'not set'):'One core annual TO'}</span>${r?`<button class="text-button" data-to="${e(r.id)}">Details →</button>`:'<span>Not defined yet</span>'}</div></article>`;
 }).join('')}</section><section class="foundation-shortcuts" aria-label="The foundation beneath your plan"><span class="eyebrow">YOUR FOUNDATION</span>${[['purpose','Purpose'],['tenets','Tenets'],['grit','GRIT']].map(([key,title])=>foundation()[key]?`<button class="foundation-shortcut" data-foundation="${key}"><strong>${title}</strong><span>${isAccepted(foundation()[key])?'Accepted':'Draft'} · Explore →</span></button>`:`<a class="foundation-shortcut" href="#foundation"><strong>${title}</strong><span>Define →</span></a>`).join('')}</section>`;
}
function foundationView() {
 return intro('Know what guides you.', 'Review these foundations each year. Keep what still holds; revise deliberately when something changes.')+
 `<section class="foundation-grid">${foundationCard('purpose','Purpose','A concise 1–2 sentence declaration of identity, values, and impact.')}${foundationCard('tenets','Tenets','Normally 2–5 principles you believe and put into practice.')}${foundationCard('grit','GRIT','Game-Changing Rocketing Impact Target: your memorable long-term north star.')}</section><details class="style-details"><summary>Your working style & brand source</summary><p>${e(D.brand?.status==='accepted'?'Accepted brand style is applied to this view.':'This view uses the shared template palette. Accepted personal colors, fonts, and permitted assets can be applied later.')}</p><p class="meta">${e(D.brand?.source?'Style source: '+D.brand.source:'No brand source recorded. Branding is optional.')}</p></details>`;
}
function filterOptions() {
 return `<label>Pillars<select id="pillar-filter"><option value="">All pillars</option>${pillars.map(([p])=>`<option ${pillarFilter===p?'selected':''} value="${e(p)}">${e(p)}</option>`).join('')}</select></label><label>Status<select id="status-filter"><option value="">All statuses</option>${['Backlog','Doing','Done'].map(s=>`<option ${statusFilter===s?'selected':''}>${s}</option>`).join('')}</select></label>`;
}
function yearButtons() {
 return `<div class="year-buttons" role="group" aria-label="Filter by planning year"><span class="eyebrow">PLANNING YEAR</span>${availableYears.map(y=>`<button class="button small ${selected===y?'primary':''}" data-plan-year="${y}" aria-pressed="${selected===y}">${y}</button>`).join('')}</div>`;
}
function objectiveView(quarterly=false) {
 const all=rows().filter(r=>quarterly?r.quarter===quarter:!r.quarter);
 const filtered=all.filter(r=>(!pillarFilter||r.pillar===pillarFilter)&&(!statusFilter||r.status===statusFilter));
 let html=intro(quarterly?'Quarterly Focus':'Target Objectives (TOs)',quarterly?'One focused quarter. Supporting Target Objectives (TOs) that move your annual results forward.':'One core measurable result per pillar. An annual Target Objective (TO) can finish before the year ends.');
 html+=`<div class="view-controls">${yearButtons()}<div class="filters">${quarterly?`<label>Quarter<select id="quarter-select">${[1,2,3,4].map(q=>`<option value="${q}" ${q===quarter?'selected':''}>Q${q}</option>`).join('')}</select></label>`:''}${filterOptions()}</div><span class="results-count">${filtered.length} TOs</span></div>`;
 if(quarterly && (quarterReview()?.open_items||[]).length)html+=`<section class="note" aria-label="Tracking details to finish"><strong>Tracking details to finish</strong><ul class="list">${quarterReview().open_items.map(item=>`<li>${e(item)}</li>`).join('')}</ul></section>`;
 if(!quarterly) return html+`<section class="annual-grid" aria-label="Annual Target Objectives">${filtered.length?filtered.map(objectiveCard).join(''):empty(all.length?'No Target Objectives match these filters.':'No annual TOs defined yet.')}</section>`;
 html+=`<section class="quarter-grid" aria-label="Quarterly Target Objectives">${pillars.map(([p],index)=>{
 const group=all.filter(r=>r.pillar===p), visible=filtered.filter(r=>r.pillar===p);if(!visible.length)return '';
 const total=group.reduce((s,r)=>s+(r.weight??100),0);
 const valid=group.every(isAccepted)&&group.every(r=>['target_review_state','weight_review_state','measurement_review_state'].every(k=>dimensionAccepted(r,k)))&&Math.abs(total-100)<.00001&&group.every(r=>progress(r)!==null);
 const score=valid?group.reduce((s,r)=>s+Math.min(100,Math.max(0,progress(r)))*(r.weight??100)/100,0):null;
 return `<section class="quarter-pillar pillar-${index}" aria-label="${e(p)} quarterly support"><header class="quarter-pillar-head"><h2>${e(p)}</h2><span class="meta">${fmt(total)}% allocated · ${score===null?'Progress pending':fmt(score)+'% progress'}</span></header>${visible.map(objectiveCard).join('')}</section>`;
 }).join('')||empty(all.length?'No Target Objectives match these filters.':'No supporting TOs defined for this quarter. Quarterly support is optional.')}</section><details class="tracking-help"><summary>How quarterly progress works</summary><p>Quarterly commitment progress and annual outcome progress are separate. Completing an enabling result does not prove the annual outcome improved. Progress bars cap at 100%; actual values remain visible. Aggregates require accepted targets, weights and measurement definitions, weights totaling 100%, and recorded measurements for every supporting TO. Pillar summaries include all TOs in the selected quarter; status filters only narrow the displayed TOs.</p></details>`;
 return html;
}
function reviewsView() {
 const y=year(), recap=y?.recap;
 return intro('Learn before you plan.', 'Look honestly at what worked, what did not, and what deserves to change.')+
 `${D.checkpoint?.next_action?`<details class="tracking-help"><summary>Planning checkpoint</summary><p>${e(D.checkpoint.next_action)}</p></details>`:''}<div class="two-col"><section class="card"><span class="eyebrow">CURRENT YEAR WRAP & RECAP</span><h2 style="margin-top:12px">Take the learning forward.</h2>${recap?`<p class="review-text">${e(recap.text)}</p><p class="meta">As of ${e(recap.as_of||'not recorded')} · ${e(recap.basis||'Results and forecasts should be distinguished')}</p>`:empty('Your recap will appear here after reflection. In October–December, separate results to date from year-end expectations.')}<ul class="list muted"><li>What worked? What did not?</li><li>What did we learn?</li><li>What will we continue, change, or stop?</li><li>What will we no longer tolerate?</li></ul></section><section class="card"><h2>Keep your commitments feasible.</h2><h3>Stop / change decisions</h3>${(y?.stop_doing||[]).length?`<ul class="list">${y.stop_doing.map(t=>`<li>${e(t)}</li>`).join('')}</ul>`:empty('No decisions recorded yet.')}<h3 style="margin-top:20px">Open questions</h3>${(D.checkpoint?.open_questions||[]).length?`<ul class="list">${D.checkpoint.open_questions.map(t=>`<li>${e(t)}</li>`).join('')}</ul>`:empty('No open questions recorded.')}</section></div><div class="section-head"><h2>Quarterly reviews</h2><span>Results → lessons → next commitments</span></div><section class="stack">${(y?.reviews||[]).length?y.reviews.map(r=>`<article class="card"><div class="pillar-top"><h3>${e(r.title||'Quarterly review')}</h3>${badge(r.date||'Undated')}</div><p class="review-text">${e(r.text)}</p>${r.next_action?`<p><strong>Next:</strong> ${e(r.next_action)}</p>`:''}</article>`).join(''):empty('Quarterly reflections will appear here. Reviews are not scheduled automatically.')}</section>`;
}
function historyView() {
 let html=intro('See how your direction evolves.', 'Keep previous plans intact. Compare results only when the measurement definitions match.');
 if(!years.length) return html+empty('Your year-to-year history begins with your first saved annual plan.');
 html+=`<div class="table-wrap"><table><caption class="sr-only">Saved planning years</caption><thead><tr><th>Year</th><th>Word of the Year</th><th>Annual TOs</th><th>Reviews</th><th>Plan state</th></tr></thead><tbody>${years.map(y=>`<tr><td><button class="text-button" data-year="${y.year}">${y.year} →</button></td><td>${e(isAccepted(y.word)?y.word.text:'Not accepted yet')}</td><td>${active(y.objectives).filter(r=>!r.quarter).length} / 6 defined</td><td>${(y.reviews||[]).length}</td><td>${e(y.status||'draft')}</td></tr>`).join('')}</tbody></table></div>`;
 const current=rows().filter(r=>!r.quarter);
 const older=years.filter(y=>y.year<selected);
 html+=`<div class="section-head"><h2>Comparable annual results</h2><span>Selected year: ${e(selected)}</span></div>`;
 const comparisons=current.flatMap(r=>older.flatMap(y=>active(y.objectives).filter(p=>!p.quarter && r.comparison_key && p.comparison_key===r.comparison_key && p.pillar===r.pillar && p.unit===r.unit && p.metric===r.metric && p.measurement===r.measurement && (p.mode||'scalar')===(r.mode||'scalar')).map(p=>`<tr><td>${e(r.pillar)}<br>${e(r.description)}</td><td>${y.year}: ${fmt(p.current)} ${e(p.unit)}<br>Target: ${fmt(p.target)}</td><td>${selected}: ${fmt(r.current)} ${e(r.unit)}<br>Target: ${fmt(r.target)}</td></tr>`)));
 return html+(comparisons.length?`<div class="table-wrap"><table><thead><tr><th>Measure</th><th>Prior year</th><th>Selected year</th></tr></thead><tbody>${comparisons.join('')}</tbody></table></div>`:empty('No confirmed comparable measurements yet. Matching pillar names alone do not establish comparability.'));
}
function guideView() {
 const steps=[['Reflect','Wrap up the current year. Name what worked, what changed, and what you will stop doing.'],['Review your foundation','Confirm Purpose, Tenets, and GRIT. Reuse accepted PBS material if available.'],['Choose an annual focus','Choose an action word or phrase and a short personal definition centered on action and impact.'],['Define six annual results','Set one measurable Target Objective (TO) for God, Fit, Fam, Biz, $, and Up. Choose the best route to the outcome.'],['Commit the next quarter','Draft support one pillar at a time, confirm counting rules and weights, and review the quarter before locking.'],['Learn and adapt','Review results, preserve history, and choose the next quarter’s commitments.']];
 return intro('A thoughtful plan. A manageable process.', 'Start with what you know. Your AI conversation helps you reflect, draft, and refine without a long questionnaire.')+
 `<div class="two-col"><section class="card">${steps.map(([t,s],i)=>`<div class="guide-step"><b>${i+1}</b><div><h3>${t}</h3><p>${s}</p></div></div>`).join('')}</section><section class="card"><h2>How to use this workspace</h2><p>This is a private, read-only snapshot of saved planning knowledge.</p><ol class="list"><li>Discuss changes in your AI conversation.</li><li>Ask AI to save the knowledge and rebuild this view.</li><li>Reload this file in your browser.</li></ol><p>Reloading alone does not rebuild the plan. Navigation and filters only change what you see.</p><h3>No required brand setup</h3><p>Accepted PBS colors, fonts, and permitted assets can personalize the view. Your planning can start without them.</p><h3>Keep projects in your project system</h3><p>Track measurable results here. Task lists and project execution stay in your existing tools.</p><button class="button primary" data-update="true">Get a refresh request</button></section></div>`;
}
function showDialog(title,html) {
 const d=document.getElementById('details');document.getElementById('dialog-title').textContent=title;document.getElementById('dialog-content').innerHTML=html;if(!d.open)d.showModal();
}
function fields(items) { return `<dl>${items.map(([k,v])=>`<dt>${e(k)}</dt><dd>${e(v??'Not recorded')}</dd>`).join('')}</dl>`; }
function supportingContext(r) {
 const notes=r.personal_notes||[];
 if(!r.importance && !notes.length)return '';
 return `<section class="to-context" aria-label="Why this matters"><h3>Why this matters</h3>${r.importance?`<p class="review-text">${e(r.importance)}</p>${r.importance_review_state==='draft'?'<p class="meta">Draft summary for your review</p>':''}`:''}${notes.length?`<details><summary>Original notes & context</summary>${notes.map(n=>`<blockquote><p>${e(typeof n==='string'?n:n.text)}</p>${typeof n==='object'&&n.source?`<cite>${e(n.source)}</cite>`:''}</blockquote>`).join('')}</details>`:''}</section>`;
}
function sourceImages(r) {
 const images=(r._related_images||[]).filter(im=>/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(im.src));
 if(!images.length)return '';
 return `<section class="to-images" aria-label="Source images"><h3>Inspiration & source images</h3>${images.map(im=>`<figure><h4>${e(im.title)}</h4><img src="${e(im.src)}" alt="${e(im.alt)}"><figcaption>${e(im.caption)}<span class="image-path">${e(im.path)}</span></figcaption></figure>`).join('')}</section>`;
}
function worksheets(r) {
 if(!(r._worksheets||[]).length)return '';
 return `<section class="to-worksheets" aria-label="Planning & reflection templates"><h3>Plan & reflect</h3><p class="meta">Use a fresh copy for each record, or work through it in your AI conversation. This view is read-only.</p>${r._worksheets.map(sheet=>`<details><summary>${e(sheet.title)}</summary><pre>${e(sheet.text)}</pre><button class="button small" data-copy-worksheet>Copy template</button><p class="meta copy-status" aria-live="polite"></p></details>`).join('')}</section>`;
}
function refreshHelp() {
 const prompt='Update my Strategic Plan view from my saved planning knowledge. Save agreed changes, rebuild and validate the dashboard, and return the same HTML file link. Preserve prior years and accepted brand inputs.';
 showDialog('Update your saved view',`<p>The page cannot send a message to AI or save changes itself.</p><p>Send this request in your planning conversation:</p><div class="empty" id="refresh-request">${e(prompt)}</div><p style="margin-top:18px"><button class="button primary" id="copy-request">Copy request</button> <button class="button" id="reload-view">Reload saved file</button></p><p class="meta" id="copy-status" aria-live="polite">Reload after AI confirms the rebuild is complete.</p>`);
 document.getElementById('copy-request').onclick=async()=>{try{await navigator.clipboard.writeText(prompt);document.getElementById('copy-status').textContent='Copied. Paste into your AI conversation.';}catch{const range=document.createRange();range.selectNodeContents(document.getElementById('refresh-request'));const s=getSelection();s.removeAllRanges();s.addRange(range);document.getElementById('copy-status').textContent='Request selected. Use Ctrl+C or your device’s copy command.';}};
 document.getElementById('reload-view').onclick=()=>location.reload();
}
function bindContent() {
 main.querySelectorAll('[data-to]').forEach(b=>b.onclick=()=>{
 const r=rows().find(r=>r.id===b.dataset.to);if(!r)return;
 const parent=rows().find(p=>p.id===r.parent_id);
 showDialog(r.description,`${badge(r.status||'Backlog',(r.status||'').toLowerCase())} ${badge(r.review_state||'draft')}<p style="margin-top:15px">${e(r.support_rationale||'')}</p>${supportingContext(r)}${worksheets(r)}${sourceImages(r)}${fields([['TO ID',r.id],['Pillar',r.pillar],['Owner',r.owner||D.person?.name||'Not set'],['Period',selected+(r.quarter?' · Q'+r.quarter:' · Annual')],['Parent annual TO',parent?.description],['Metric / unit',r.metric+' · '+(r.unit||'Not set')],['Measurement',r.measurement],['Tracking definition',r.measurement_review_state],['Activated',r.activated_at],['Start',fmt(r.start)],['Target',fmt(r.target)],['Current',fmt(r.current)],['As of',r.as_of],['Due date',r.due_date],['Weight',r.quarter?fmt(r.weight??100)+'%':'100% · no cross-pillar score'],['Disposition',r.disposition],['Source',r.source],['Notes',r.notes]])}`);
 });
 main.querySelectorAll('[data-foundation]').forEach(b=>b.onclick=()=>{const r=foundation()[b.dataset.foundation];showDialog(b.dataset.foundation==='grit'?'GRIT':b.dataset.foundation[0].toUpperCase()+b.dataset.foundation.slice(1),`${b.dataset.foundation==='tenets'?tenetsList(r.text):`<p class="foundation-text">${e(Array.isArray(r.text)?r.text.join('\n'):r.text)}</p>`}${fields([['Review state',r.review_state],['Version',r.version],['Source',r.source],['Source version',r.source_version],['Reviewed',r.reviewed_at],['Explanation',r.explanation]])}`);});
 main.querySelectorAll('[data-word]').forEach(b=>b.onclick=()=>{const r=year().word;showDialog('Word of the Year',`<h3>${e(r.text)}</h3><p>${e(r.meaning)}</p>${fields([['Review state',r.review_state],['Why this word',r.rationale],['In practice',(r.examples||[]).join('\n')]])}`);});
 main.querySelectorAll('[data-year]').forEach(b=>b.onclick=()=>{selected=Number(b.dataset.year);quarter=year()?.current_quarter||1;document.getElementById('year-select').value=selected;location.hash='overview';render();});
 main.querySelectorAll('[data-plan-year]').forEach(b=>b.onclick=()=>{selected=Number(b.dataset.planYear);quarter=year()?.current_quarter||1;document.getElementById('year-select').value=selected;render();main.querySelector(`[data-plan-year="${selected}"]`)?.focus();});
 const pf=document.getElementById('pillar-filter');if(pf)pf.onchange=()=>{pillarFilter=pf.value;render('pillar-filter');};
 const sf=document.getElementById('status-filter');if(sf)sf.onchange=()=>{statusFilter=sf.value;render('status-filter');};
 const qs=document.getElementById('quarter-select');if(qs)qs.onchange=()=>{quarter=Number(qs.value);render('quarter-select');};
 main.querySelectorAll('[data-update]').forEach(b=>b.onclick=refreshHelp);
}
function render(focus) {
 const route=location.hash.slice(1)||'overview';
 const view={overview,foundation:foundationView,objectives:()=>objectiveView(false),quarter:()=>objectiveView(true),reviews:reviewsView,history:historyView,guide:guideView};
 const valid=Object.hasOwn(view,route)?route:'overview';
 main.className=valid+'-page';
 main.innerHTML=view[valid]();
 document.querySelectorAll('nav a').forEach(a=>{if(a.hash==='#'+valid)a.setAttribute('aria-current','page');else a.removeAttribute('aria-current');});
 document.title=(D.person?.name?D.person.name+' · ':'')+'Strategic Plan · '+routes.find(r=>r[0]===valid)[1];
 bindContent();if(focus)document.getElementById(focus)?.focus();
}
// Derive readable foregrounds for accepted brand backgrounds.
function luminance(hex) { const c=hex.slice(1).match(/../g).map(x=>{const n=parseInt(x,16)/255;return n<=.04045?n/12.92:((n+.055)/1.055)**2.4;});return .2126*c[0]+.7152*c[1]+.0722*c[2]; }
function ink(hex) { return luminance(hex)>.179?'#14242b':'#ffffff'; }
const theme=D._theme||{}; const style=document.documentElement.style;
for(const [name,fallback] of [['sidebar','#104f72'],['link','#006799'],['ink','#303D49']])style.setProperty('--'+name+'-contrast',ink(theme[name]||fallback));
if(theme.accent){style.setProperty('--accent',theme.accent);style.setProperty('--accent-ink',ink(theme.accent));style.setProperty('--link',ink(theme.accent)==='#ffffff'?theme.accent:'#006799');}
if(theme.sidebar){style.setProperty('--sidebar',theme.sidebar);style.setProperty('--sidebar-ink',ink(theme.sidebar));}
if(theme.background && luminance(theme.background)>=.82)style.setProperty('--paper',theme.background);
if(theme.font_family)style.setProperty('--font',theme.font_family+', system-ui, sans-serif');
if(D.person?.name)document.getElementById('person-label').textContent=D.person.name;
document.getElementById('monogram').textContent=D.person?.initials||'SP';
if(theme.logo){const im=document.createElement('img');im.src=theme.logo;im.alt=D.brand?.logo_alt||'Personal brand';document.getElementById('monogram').replaceChildren(im);}
document.getElementById('navigation').innerHTML=routes.map(([id,label,icon])=>`<a href="#${id}"><span class="nav-symbol" aria-hidden="true">${icon}</span>${label}</a>`).join('');
const ys=document.getElementById('year-select');ys.innerHTML=availableYears.map(y=>`<option value="${y}">${y}</option>`).join('');ys.disabled=availableYears.length===1;
ys.onchange=()=>{selected=Number(ys.value);quarter=year()?.current_quarter||1;render();};
document.getElementById('updated').textContent=D.updated_at?'Snapshot: '+D.updated_at:'Blank standard · no personal records';
document.getElementById('update-button').onclick=refreshHelp;
document.getElementById('close-dialog').onclick=()=>document.getElementById('details').close();
document.getElementById('details').addEventListener('click',async event=>{
 const button=event.target.closest('[data-copy-worksheet]');if(!button)return;
 const panel=button.closest('details'),text=panel.querySelector('pre'),status=panel.querySelector('.copy-status');
 try{await navigator.clipboard.writeText(text.textContent);status.textContent='Copied. Paste into your notes or planning conversation.';}
 catch{const range=document.createRange();range.selectNodeContents(text);const selection=getSelection();selection.removeAllRanges();selection.addRange(range);status.textContent='Template selected. Use your device’s copy command.';}
});
window.addEventListener('hashchange',()=>{render();main.focus({preventScroll:true});});
render();
})();
